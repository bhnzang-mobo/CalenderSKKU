function sub_func() {
  console.log("test!")
  document.getElementById("list_div").style.display="none";
  document.getElementById("loader_div").style.display="block";   // The function returns the product of p1 and p2
  location.href='/insertEvents'
}